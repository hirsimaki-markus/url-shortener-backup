import os
import io
import sys
import time
import json
import flask
import random
import qrcode
import logging
import datetime
import requests
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, String, Float
from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine
from sqlalchemy import exc
from flask import Flask, render_template, request


app = Flask(__name__)

logging.basicConfig(filename='/home/webservice/yxu/yxu.log', level=logging.DEBUG, format='%(asctime)s %(levelname)s %(name)s %(message)s')
logger=logging.getLogger(__name__)

engine = create_engine("sqlite:///database.db")
session = sessionmaker(bind=engine)()
Base = declarative_base()

class Links(Base):
    __tablename__ = "links"
    page = Column(String, primary_key=True)  # eli ID lyhennetylle kokonaisuudelle esim 001
    links = Column(String)  # json dumppi kaikista linkeistä tällä IDllä. esim {'urls': [{"url": url, "time": time.time(), "desc": desc}]
    def __init__(self, page, links):
        self.page = page
        self.links = links

def to_b10num(b64num):
    """convert custom b64id number to decimal"""
    b10num = 0
    for idx, decimal in enumerate(b64num[::-1]):
        #decimal_place = idx+1
        b10num += 64**idx * "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_".index(decimal)
    return b10num

def to_b64num(b10num, size):
    if b10num >= 64**size or size==0:
        raise OverflowError("Given normal does not fit in given size")
    result = []
    max_power = 0
    for i in range(size):
        if (b10num / 64**i) < 1:
            max_power = i-1
            break
    multiplier = int(b10num/64**max_power)
    for i in reversed(range(max_power)):
        i += 1
        multiplier = int(b10num/64**i)
        b10num = b10num-64**i*multiplier
        result.append(multiplier)
    result.append(b10num)
    lookup = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"
    result = [lookup[i] for i in result]
    return "".join(result).rjust(size, "0")

@app.route('/', methods=['GET', 'POST'])
def root():
    """handler for the root /"""

    # handler for getting the root
    if request.method == 'GET':
        return render_template('index.html')

    # handler for posting to root
    if request.method == 'POST':
        url = request.form['url'] # extract the url user is inputting
        desc = request.form['description']
        if len(url) > 2000:
            return "Too long URI"
        # side effects
        ### logger.log(logging.DEBUG, ": [ " + str(type(text)) + " ]")
        logger.log(logging.DEBUG, ": [ " + url + " ]")
        ID_SIZE = 1
        TIME_RESOLUTION = 60 # in seconds
        OVERWRITE = False  # if true more items can be added to a given ID eg 001
        retry_counter = 0
        number = random.randint(0, 64**ID_SIZE - 1)
        while True:
            b64id = to_b64num(number, ID_SIZE)
            if retry_counter >= 64**ID_SIZE: # database ahs been traversed once. enable overwrite
                OVERWRITE = True
            if retry_counter >= 64**ID_SIZE * 2:
                # database has been traversed two times. no success for using new id and no success for overwriting
                # b64id = "ERROR DATABASE FULL WITH ID SIZE " + str(ID_SIZE) + " AND TIME RESOLUTION DOES NOT ALLOW OVERWRITING. try again later :DDD"
                session.close()
                # !!!!!!!!!!!!! throw error to user instead of looping forever. database is full for the specific ID size. could use break and silently return also. lol
                return "Error: Overwrite required to store new link without increasing ID size. Time resolution disallows overwrite. Try again later."            
            retry_counter += 1
            number += 1
            number = number % 64**ID_SIZE
            if OVERWRITE:
                existing_page = session.query(Links).get(b64id)

                existing_page_links = json.loads(existing_page.links) # take a single instance of the class aka a single page like 001. extract data under that id.

                freshest_timestamp = 0
                for link in existing_page_links["links"]:
                    if link["time"] > freshest_timestamp:
                        freshest_timestamp = link["time"]
                
                if time.time() > freshest_timestamp + TIME_RESOLUTION: # just update existing link

                    ##### # get link creators IP address and country. second copy of this block is below
                    ##### # =================[ rate limit problem. country is hardcoded ]=========================
                    ##### headers_list = request.headers.getlist("X-Forwarded-For")
                    ##### user_ip = headers_list[0] if headers_list else request.remote_addr
                    ##### response = requests.get('http://ip-api.com/json/' + user_ip)
                    ##### country = response.json()["country"]
                    country = "Finland"

                    existing_page_links["links"].append({"url": url, "time": time.time(), "desc": desc, "country": country})
                    existing_page.links = json.dumps(existing_page_links)
                    session.commit()
                    session.close()
                    break
                else:
                    continue
            else: # no overwriting. adding new item to database
                try:
                    ##### # get link creators IP address and country. second copy of this block is below
                    ##### # =================[ rate limit problem. country is hardcoded ]=========================
                    ##### headers_list = request.headers.getlist("X-Forwarded-For")
                    ##### user_ip = headers_list[0] if headers_list else request.remote_addr
                    ##### response = requests.get('http://ip-api.com/json/' + user_ip)
                    ##### country = response.json()["country"]
                    country = "Finland"

                    links_dump = json.dumps({'links': [{"url": url, "time": time.time(), "desc": desc, "country": country}]})
                    new_page = Links(b64id, links_dump)
                    session.add(new_page)
                    session.commit()
                    session.close()
                    break
                except exc.IntegrityError:
                    session.rollback()
                    continue

        return render_template('resultspage.html', final_link="http://51.75.200.42/"+b64id)
        # return b64id + "<br>" + "Your link: " + url.upper()

@app.route('/<b64id>')
def shortlink(b64id):

    def table_row_gen(page_links):
        accumulator = ""
        
        for link_dict in page_links["links"]:
            tr_template = r"""
                <tr>
                    <td class="table-link"><img style="position: relative;top: 10px;padding-top; -10px" src="{favicon}" alt="Sample alt text" width="32" height="32">{url}</td>
                    <td class="table-description">{description}</td>
                    <td class="table-country">{country}</td>
                    <td class="table-timestamp">{timestamp}</td>
                </tr>
            """.format(favicon="https://www.google.com/s2/favicons?sz=64&domain_url={}".format(link_dict["url"]),
                       url="<a href='{x}'>{x}</a>".format(x=link_dict["url"]),
                       description=link_dict["desc"],
                       country=link_dict["country"],
                       timestamp=str(datetime.datetime.fromtimestamp(link_dict["time"])).split()[0])
            accumulator += tr_template
        # <img src="https://www.google.com/s2/favicons?sz=64&domain_url=https://google.com" alt="Sample alt text" width="64" height="64">
        return accumulator
    logger.log(logging.DEBUG, ": [ address: " + b64id + " ]")

    if request.query_string.decode("ascii") == "qr":
        img_buf = io.BytesIO()
        img = random_qr(url="http://51.75.200.42/"+b64id)
        img.save(img_buf)
        img_buf.seek(0)
        return flask.send_file(img_buf, mimetype='image/png')

    page = session.query(Links).get(b64id)

    if page is not None:
        page_links = json.loads(page.links)
        #logger.log(logging.DEBUG, ": [ address: " + request.remote_addrd + " ]")
        return render_template('receivepage.html', table_rows=table_row_gen(page_links))
        # return str(page_links)
    else:
        return "Not found :("

@app.route('/howto')
def howto():
    return render_template('howto.html')

@app.route('/help')
def sitehelp():
    return render_template('help.html')

def random_qr(url='www.google.com'):
    qr = qrcode.QRCode(version=1,
                       error_correction=qrcode.constants.ERROR_CORRECT_L,
                       box_size=10,
                       border=4)
    qr.add_data(url)
    qr.make(fit=True)
    img = qr.make_image()
    return img

if __name__ == "__main__":
    try:
        app.run(host='0.0.0.0')
    except exception as e:
        logger.error(e)
